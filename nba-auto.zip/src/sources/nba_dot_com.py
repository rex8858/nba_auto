# NBA.com 來源解析骨架（示範）
def fetch_schedule_et(date_et: str):
    return []
def fetch_box_advanced(game_id: str):
    return {}
